using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace JorgeGame
{
public class UIControler : MonoBehaviour
{
    // imagenes que representan las vidas (corazones)
    public Image[] livesImages;

    // sprite que se usa cuando se pierde una vida
    public Sprite spendLives;

    // texto donde se muestran las monedas
    public TextMeshProUGUI coinsText;

    void Start()
    {
        // al iniciar actualiza todas las vidas en pantalla
        UpdateAllLives();
    }

    // actualiza el corazon que corresponde a la vida perdida
    public void UpdateLives()
    {
        // obtiene las vidas actuales
        int lives = GameControl.Instance.GetCurrentLives();

        // cambia solo el corazon correspondiente cuando pierde una vida
        if (lives >= 0 && lives < livesImages.Length)
        {
            livesImages[lives].sprite = spendLives;
        }
    }

    // sincroniza todos los corazones al estado actual de vidas
    public void UpdateAllLives()
    {
        // actualiza todos los corazones al iniciar el juego
        int lives = GameControl.Instance.GetCurrentLives();

        for (int i = 0; i < livesImages.Length; i++)
        {
            if (i >= lives)
            {
                // los que ya no tiene se muestran como perdidos
                livesImages[i].sprite = spendLives;
            }
        }
    }

    // actualiza el texto del contador de monedas
    public void UpdateCoins(int coins)
    {
        // muestra la cantidad de monedas en la interfaz
        coinsText.text = coins.ToString();
    }
}
}